package com.example.fintech;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FintechApplicationTests {

    @Test
    void contextLoads() {
    }

}
