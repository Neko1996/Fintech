package com.example.fintech.stock.exception;

public class StockNotFoundException extends RuntimeException{
}
