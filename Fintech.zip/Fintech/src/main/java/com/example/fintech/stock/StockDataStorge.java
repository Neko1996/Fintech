package com.example.fintech.stock;

import org.springframework.context.annotation.Configuration;

@Configuration
public class StockDataStorge {
//    @Bean
//    public List<Stock> stocks(){
//        List<Stock> stocks = Arrays.asList(
//                new Stock("2021-8-11",
//                        "arm",
//                        12.22,
//                        12.22,
//                        12.22,
//                        12.22),
//                new Stock("2021-11-11",
//                        "arm2",
//                        12.22,
//                        12.22,
//                        12.22,
//                        12.22)
//        );
//        return stocks;
//    }
}
